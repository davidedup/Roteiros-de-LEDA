package adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T> implements
		DoubleLinkedList<T> {

	public DoubleLinkedListNode<T> last;

	@Override
	public void insertFirst(T element) {
		if(super.head.isNIL()){
			DoubleLinkedListNode<T> toAdd = new DoubleLinkedListNode<>(element, new DoubleLinkedListNode<>(), new DoubleLinkedListNode<>());
			super.head = toAdd;
			this.last = toAdd;
		}else{
			DoubleLinkedListNode<T> toAdd = new DoubleLinkedListNode<>(element, (DoubleLinkedListNode<T>) this.head, new DoubleLinkedListNode<>());
			this.head = toAdd;
		}
	}
	
	@Override
	public void removeFirst() {
		if(isEmpty()){
			return;
		}
		super.head = super.head.getNext();
	}

	@Override
	public void removeLast() {
		this.last = this.last.getPrevious();
	}

	public DoubleLinkedListNode<T> getLast() {
		return last;
	}

	public void setLast(DoubleLinkedListNode<T> last) {
		this.last = last;
	}
	
	public SingleLinkedListNode<T> getHead() {
		return super.head;
	}
	

}
