package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {

	protected SingleLinkedListNode<T> head;

	public SingleLinkedListImpl() {
		this.head = new SingleLinkedListNode<T>();
	}

	@Override
	public boolean isEmpty() {
		return this.head.isNIL();
	}

	@Override
	public int size() {
		int size = 0;
		SingleLinkedListNode<T> currentNode = this.head;
		if (this.isEmpty()){
			return size;
		}
		
		while(currentNode != null){
			size++;
			currentNode = currentNode.getNext();
		}
		return size;
	}

	@Override
	public T search(T element) {
		SingleLinkedListNode<T> currentNode = this.head;
		while(currentNode != null){
			if(currentNode.getData().equals(element)){
				return currentNode.getData();
			}
			currentNode = currentNode.getNext();
		}
		return null;
	}

	@Override
	public void insert(T element) {
		SingleLinkedListNode<T> currentNode = this.head;
		
		if (element == null){
			return;
		}
		
		if(this.head.isNIL()){
			this.head = new SingleLinkedListNode<>(element,null);
			return;
		}
		
		while(currentNode.next != null){
			currentNode = currentNode.getNext();
		}
		currentNode.next = new SingleLinkedListNode<>(element,null);		
		
	}

	@Override
	public void remove(T element) {
		if(element == null) return;
		
		if(this.head.data == null) return;
		
		if(this.head.data.equals(element)){
			this.head = this.head.next;
		}
		
		SingleLinkedListNode<T> currentNode = this.head;
		
		while(currentNode.next != null){
			if(currentNode.next.data.equals(element)){
				currentNode.next = currentNode.next.next;
				return;
			}
			currentNode = currentNode.next;
		}
		
	}

	@Override
	public T[] toArray() {
		int i = 0;

		T[] arrayOfElements = (T[]) new Object[this.size()];
		
		if(this.head.isNIL()){
			return arrayOfElements;
		}
		
		SingleLinkedListNode<T> currentNode = this.head;
		
		while(currentNode != null){
			arrayOfElements[i] = currentNode.data;
			i++;
			currentNode = currentNode.next;
		}
		
		return arrayOfElements;
		
	}

	public SingleLinkedListNode<T> getHead() {
		return head;
	}

	public void setHead(SingleLinkedListNode<T> head) {
		this.head = head;
	}

}
